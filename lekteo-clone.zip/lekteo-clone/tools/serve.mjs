/**
 * Minimal local preview server — developer convenience only.
 *
 * The website itself is 100% static: this script is NOT part of the deployed site and is
 * never needed on GitHub Pages. It only exists so `npm start` works with zero dependencies.
 *
 *   node tools/serve.mjs            → http://localhost:4173/
 *   PORT=8080 node tools/serve.mjs  → http://localhost:8080/
 */
import { createServer } from "node:http";
import { createReadStream } from "node:fs";
import { stat } from "node:fs/promises";
import { extname, join, normalize, sep } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const PORT = Number(process.env.PORT || 4173);
const HOST = process.env.HOST || "127.0.0.1";

const TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".woff2": "font/woff2",
  ".woff": "font/woff",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".txt": "text/plain; charset=utf-8",
  ".md": "text/markdown; charset=utf-8",
  ".map": "application/json; charset=utf-8",
};

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url || "/", `http://${req.headers.host}`);
    // collapse duplicate slashes so a request for "//" behaves like "/"
    let pathname = decodeURIComponent(url.pathname).replace(/\/{2,}/g, "/");
    if (pathname.endsWith("/")) pathname += "index.html";

    const target = normalize(join(ROOT, pathname));
    if (!target.startsWith(ROOT.endsWith(sep) ? ROOT : ROOT + sep)) {
      res.writeHead(403).end("Forbidden");
      return;
    }

    const info = await stat(target).catch(() => null);
    if (!info || info.isDirectory()) {
      res.writeHead(404, { "content-type": "text/html; charset=utf-8" });
      res.end(
        '<!doctype html><meta charset="utf-8"><title>404</title>' +
          '<body style="font:16px system-ui;padding:3rem"><h1>404 — Not found</h1>' +
          '<p><a href="/">Back to the page</a></p></body>'
      );
      return;
    }

    res.writeHead(200, {
      "content-type": TYPES[extname(target).toLowerCase()] || "application/octet-stream",
      "content-length": info.size,
      "cache-control": "no-cache",
    });
    createReadStream(target).pipe(res);
  } catch (error) {
    res.writeHead(500).end("Internal preview-server error");
    console.error(error);
  }
});

server.listen(PORT, HOST, () => {
  console.log(`Preview running at http://${HOST}:${PORT}/  (Ctrl+C to stop)`);
});
