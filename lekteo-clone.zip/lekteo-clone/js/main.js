/* ======================================================================
     Appearance controls + small placeholder interactions.
     No file handling, no network, no business logic.
     ====================================================================== */
  (function () {
    var root = document.documentElement;
    var KEY = "lekteo.theme";
    var group = document.querySelector("[data-theme-group]");
    var buttons = group ? Array.prototype.slice.call(group.querySelectorAll("button")) : [];

    var labels = {
      light: "Thème clair",
      dark: "Thème sombre",
      system: "Automatique : comme mon système"
    };

    function current() {
      return root.getAttribute("data-theme") || "system";
    }

    function sync() {
      var mode = current();
      buttons.forEach(function (button) {
        var on = button.getAttribute("data-theme-choice") === mode;
        button.setAttribute("aria-pressed", on ? "true" : "false");
        var label = button.querySelector(".sr-only");
        var text = labels[button.getAttribute("data-theme-choice")] || "";
        if (label) label.textContent = on ? text + " (actif)" : text;
        button.setAttribute("title", text);
      });
    }

    buttons.forEach(function (button) {
      button.addEventListener("click", function () {
        var choice = button.getAttribute("data-theme-choice");
        if (choice === "system") {
          root.removeAttribute("data-theme");
        } else {
          root.setAttribute("data-theme", choice);
        }
        try {
          if (choice === "system") localStorage.removeItem(KEY);
          else localStorage.setItem(KEY, choice);
        } catch (e) {}
        sync();
      });
    });
    sync();

    /* Dismiss the language suggestion strip. */
    var dismiss = document.querySelector("[data-dismiss-lang]");
    if (dismiss) {
      dismiss.addEventListener("click", function () {
        var strip = document.getElementById("lang-suggest");
        if (strip) strip.remove();
      });
    }

    /* Every link is a visual placeholder: never navigate away. */
    document.addEventListener("click", function (event) {
      var link = event.target.closest ? event.target.closest('a[href="#"]') : null;
      if (link) event.preventDefault();
    });

    /* Keep the decorative drop area behaving like a control, without any upload. */
    var dropzone = document.querySelector(".dropzone");
    if (dropzone) {
      dropzone.addEventListener("keydown", function (event) {
        if (event.key === " " || event.key === "Enter") event.preventDefault();
      });
    }
  })();
